#include "graph.h"
#include <fstream>

/***************************************************
                    VERTEX
****************************************************/

/// Le constructeur met en place les �l�ments de l'interface
VertexInterface::VertexInterface(int idx, int x, int y, std::string pic_name, int pic_idx)
{
    // La boite englobante
    m_top_box.set_pos(x, y);
    m_top_box.set_dim(130, 100);
    m_top_box.set_moveable();

    // Le slider de r�glage de valeur
    m_top_box.add_child( m_slider_value );
    m_slider_value.set_range(0.0 , 100.0); // Valeurs arbitraires, � adapter...
    m_slider_value.set_dim(20,80);
    m_slider_value.set_gravity_xy(grman::GravityX::Left, grman::GravityY::Up);

    // Label de visualisation de valeur
    m_top_box.add_child( m_label_value );
    m_label_value.set_gravity_xy(grman::GravityX::Left, grman::GravityY::Down);

    // Une illustration...
    if (pic_name!="")
    {
        m_top_box.add_child( m_img );
        m_img.set_pic_name(pic_name);
        m_img.set_pic_idx(pic_idx);
        m_img.set_gravity_x(grman::GravityX::Right);
    }

    // Label de visualisation d'index du sommet dans une boite
    m_top_box.add_child( m_box_label_idx );
    m_box_label_idx.set_gravity_xy(grman::GravityX::Right, grman::GravityY::Down);
    m_box_label_idx.set_dim(20,12);
    m_box_label_idx.set_bg_color(BLANC);

    m_box_label_idx.add_child( m_label_idx );
    m_label_idx.set_message( std::to_string(idx) );
}


/// Gestion du Vertex avant l'appel � l'interface
void Vertex::pre_update()
{
    if (!m_interface)
        return;

    /// Copier la valeur locale de la donn�e m_value vers le slider associ�
    m_interface->m_slider_value.set_value(m_value);

    /// Copier la valeur locale de la donn�e m_value vers le label sous le slider
    m_interface->m_label_value.set_message( std::to_string( (int)m_value) );
}


/// Gestion du Vertex apr�s l'appel � l'interface
void Vertex::post_update()
{
    if (!m_interface)
        return;

    /// Reprendre la valeur du slider dans la donn�e m_value locale
    m_value = m_interface->m_slider_value.get_value();
}



/***************************************************
                    EDGE
****************************************************/

/// Le constructeur met en place les �l�ments de l'interface
EdgeInterface::EdgeInterface(Vertex& from, Vertex& to)
{
    // Le WidgetEdge de l'interface de l'arc
    if ( !(from.m_interface && to.m_interface) )
    {
        std::cerr << "Error creating EdgeInterface between vertices having no interface" << std::endl;
        throw "Bad EdgeInterface instanciation";
    }
    m_top_edge.attach_from(from.m_interface->m_top_box);
    m_top_edge.attach_to(to.m_interface->m_top_box);
    m_top_edge.reset_arrow_with_bullet();

    // Une boite pour englober les widgets de r�glage associ�s
    m_top_edge.add_child(m_box_edge);
    m_box_edge.set_dim(24,60);
    m_box_edge.set_bg_color(BLANCBLEU);

    // Le slider de r�glage de valeur
    m_box_edge.add_child( m_slider_weight );
    m_slider_weight.set_range(0.0 , 100.0); // Valeurs arbitraires, � adapter...
    m_slider_weight.set_dim(16,40);
    m_slider_weight.set_gravity_y(grman::GravityY::Up);

    // Label de visualisation de valeur
    m_box_edge.add_child( m_label_weight );
    m_label_weight.set_gravity_y(grman::GravityY::Down);

}


/// Gestion du Edge avant l'appel � l'interface
void Edge::pre_update()
{
    if (!m_interface)
        return;

    /// Copier la valeur locale de la donn�e m_weight vers le slider associ�
    m_interface->m_slider_weight.set_value(m_weight);

    /// Copier la valeur locale de la donn�e m_weight vers le label sous le slider
    m_interface->m_label_weight.set_message( std::to_string( (int)m_weight ) );
}

/// Gestion du Edge apr�s l'appel � l'interface
void Edge::post_update()
{
    if (!m_interface)
        return;

    /// Reprendre la valeur du slider dans la donn�e m_weight locale
    m_weight = m_interface->m_slider_weight.get_value();
}



/***************************************************
                    GRAPH
****************************************************/

/// Ici le constructeur se contente de pr�parer un cadre d'accueil des
/// �l�ments qui seront ensuite ajout�s lors de la mise ne place du Graphe
GraphInterface::GraphInterface(int x, int y, int w, int h)
{
    m_top_box.set_dim(1000,740);
    m_top_box.set_gravity_xy(grman::GravityX::Right, grman::GravityY::Up);

    m_top_box.add_child(m_tool_box);
    m_tool_box.set_dim(80,720);
    m_tool_box.set_gravity_xy(grman::GravityX::Left, grman::GravityY::Up);
    m_tool_box.set_bg_color(BLANCBLEU);

    m_top_box.add_child(m_main_box);
    m_main_box.set_dim(908,720);
    m_main_box.set_gravity_xy(grman::GravityX::Right, grman::GravityY::Up);
    m_main_box.set_bg_color(BLANCJAUNE);

    m_tool_box.add_child( m_bouton1 );
//    m_boite_boutons.set_dim(80,60);
//    m_boite_boutons.set_gravity_xy(grman::GravityX::Left, grman::GravityY::Center );
//    m_boite_boutons.set_bg_color(FUCHSIACLAIR);
//    m_boite_boutons.set_moveable();

    //m_boite_boutons.add_child( m_bouton1 );
    m_bouton1.set_frame(3,3,80,60);
    m_bouton1.set_bg_color(FUCHSIA);

    m_bouton1.add_child(m_bouton1_label);
    m_bouton1_label.set_message("SUPPRIMER");


}

GraphInterface2::GraphInterface2(int x, int y, int w, int h)
{
    m_box.set_dim(1000,740);
    m_box.set_gravity_xy(grman::GravityX::Right, grman::GravityY::Up);
    m_bouton10.set_frame(100,10,70,50);
    m_bouton10.set_bg_color(FUCHSIA);

    m_box.add_child(m_bouton10);
    m_bouton10.add_child(m_bouton10_label);
    m_bouton10_label.set_message("RESEAU 1");

    m_bouton20.set_frame(450,10,70,50);
    m_bouton20.set_bg_color(FUCHSIA);

    m_box.add_child(m_bouton20);
    m_bouton20.add_child(m_bouton20_label);
    m_bouton20_label.set_message("RESEAU 2");

    m_bouton30.set_frame(800,10,70,50);
    m_bouton30.set_bg_color(FUCHSIA);

    m_box.add_child(m_bouton30);
    m_bouton30.add_child(m_bouton30_label);
    m_bouton30_label.set_message("RESEAU 3");

    m_bouton40.set_frame(55,300,150,50);
    m_bouton40.set_bg_color(FUCHSIA);

    m_box.add_child(m_bouton40);
    m_bouton40.add_child(m_bouton40_label);
    m_bouton40_label.set_message("RESEAU REDUIT 1");

    m_bouton50.set_frame(405,300,150,50);
    m_bouton50.set_bg_color(FUCHSIA);

    m_box.add_child(m_bouton50);
    m_bouton50.add_child(m_bouton50_label);
    m_bouton50_label.set_message("RESEAU REDUIT 2");

    m_bouton60.set_frame(755,300,150,50);
    m_bouton60.set_bg_color(FUCHSIA);

    m_box.add_child(m_bouton60);
    m_bouton60.add_child(m_bouton60_label);
    m_bouton60_label.set_message("RESEAU REDUIT 3");
}

void Graph::clearMap()
{
    m_vertices.clear();
    m_edges.clear();
}

/// M�thode sp�ciale qui construit un graphe arbitraire (d�mo)
/// Cette m�thode est � enlever et remplacer par un syst�me
/// de chargement de fichiers par exemple.
/// Bien s�r on ne veut pas que vos graphes soient construits
/// "� la main" dans le code comme �a.
void Graph::make_example(std::string a)
{
    m_interface = std::make_shared<GraphInterface>(50, 0, 750, 600);
    std::ifstream fichier(a, std::ios::in);

    int indiceEdge, posx, posy, vertexin, vertexout, indiceVertex;
    double poidEdge, poidVertex;
    std::string picname;

    if(fichier)
    {
        fichier >> Graph::ordre;
        fichier >> Graph::nbrEdge;

///---------------------------------------------------------------------------------------------
///METHODE POUR LE GRAPHE COMPLEXE & SIMPLIFIE
///---------------------------------------------------------------------------------------------
        for(int i=0; i < ordre; i++)
        {
            fichier >> poidVertex;
            fichier >> posx;
            fichier >> posy;
            fichier >> picname;

            add_interfaced_vertex(i,poidVertex,posx,posy,picname);


        }

        for (int j=0; j<nbrEdge; j++)
        {
            fichier >> vertexin;
            fichier >> vertexout;
            fichier >> poidEdge;

            add_interfaced_edge(j,vertexin,vertexout,poidEdge);

        }

        fichier.close();

    }

    // La ligne pr�c�dente est en gros �quivalente � :
    // m_interface = new GraphInterface(50, 0, 750, 600);

    /// Les sommets doivent �tre d�finis avant les arcs
    // Ajouter le sommet d'indice 0 de valeur 30 en x=200 et y=100 avec l'image clown1.jpg etc...


        /// Les arcs doivent �tre d�finis entre des sommets qui existent !
    // AJouter l'arc d'indice 0, allant du sommet 1 au sommet 2 de poids 50 etc...

}

std::string Graph::menu1(std::string a)
{
    m_interface2 = std::make_shared<GraphInterface2>(50, 0, 750, 600);
    m_interface2->m_box.set_bg_color(JAUNE);
    m_interface2->m_box.update();
    if ( m_interface2->m_bouton10.clicked() )
    {
        std::cout << "Vous avez selectionner le reseau 1." << std::endl << "Appuyez sur la touche D de votre clavier" << std::endl;
        a="fichpetit.txt";
    }

    if ( m_interface2->m_bouton20.clicked() )
    {
        std::cout << "Vous avez selectionner le reseau 2." << std::endl << "Appuyez sur la touche D de votre clavier" << std::endl;
        a="fichgrand.txt";
    }

    if ( m_interface2->m_bouton30.clicked() )
    {
        std::cout << "Vous avez selectionner le reseau 3." << std::endl << "Appuyez sur la touche D de votre clavier" << std::endl;
        a="fichmarin.txt";
    }

    if ( m_interface2->m_bouton40.clicked() )
    {
        std::cout << "Vous avez selectionner le reseau reduit 1." << std::endl << "Appuyez sur la touche D de votre clavier" << std::endl;
        a="simplipetit.txt";
    }

    if ( m_interface2->m_bouton50.clicked() )
    {
        std::cout << "Vous avez selectionner le reseau reduit 2." << std::endl << "Appuyez sur la touche D de votre clavier" << std::endl;
        a="simpligrand.txt";
    }

    if ( m_interface2->m_bouton60.clicked() )
    {
        std::cout << "Vous avez selectionner le reseau reduit 3." << std::endl << "Appuyez sur la touche D de votre clavier" << std::endl;
        a="simplimarin.txt";
    }

    return a;
}

/// La m�thode update � appeler dans la boucle de jeu pour les graphes avec interface
void Graph::update()
{


    if (!m_interface)
        return;


    for (auto &elt : m_vertices)
        elt.second.pre_update();

    for (auto &elt : m_edges)
        elt.second.pre_update();

    m_interface->m_top_box.update();
    if ( m_interface->m_bouton1.clicked() )
    {
       effacage();
    }

    for (auto &elt : m_vertices)
        elt.second.post_update();

    for (auto &elt : m_edges)
        elt.second.post_update();

}

/// Aide � l'ajout de sommets interfac�s
void Graph::add_interfaced_vertex(int idx, double value, int x, int y, std::string pic_name, int pic_idx )
{
    if ( m_vertices.find(idx)!=m_vertices.end() )
    {
        std::cerr << "Error adding vertex at idx=" << idx << " already used..." << std::endl;
        throw "Error adding vertex";

    }
    // Cr�ation d'une interface de sommet
    VertexInterface *vi = new VertexInterface(idx, x, y, pic_name, pic_idx);
    // Ajout de la top box de l'interface de sommet
    m_interface->m_main_box.add_child(vi->m_top_box);
    // On peut ajouter directement des vertices dans la map avec la notation crochet :
    m_vertices[idx] = Vertex(value, vi);
}

/// Aide � l'ajout d'arcs interfac�s
void Graph::add_interfaced_edge(int idx, int id_vert1, int id_vert2, double weight)
{
    if ( m_edges.find(idx)!=m_edges.end() )
    {
        std::cerr << "Error adding edge at idx=" << idx << " already used..." << std::endl;
        throw "Error adding edge";
    }

    if ( m_vertices.find(id_vert1)==m_vertices.end() || m_vertices.find(id_vert2)==m_vertices.end() )
    {
        std::cerr << "Error adding edge idx=" << idx << " between vertices " << id_vert1 << " and " << id_vert2 << " not in m_vertices" << std::endl;
        throw "Error adding edge";
    }

    EdgeInterface *ei = new EdgeInterface(m_vertices[id_vert1], m_vertices[id_vert2]);
    m_interface->m_main_box.add_child(ei->m_top_edge);
    m_edges[idx] = Edge(weight, ei);

    m_edges[idx].m_from = id_vert1;
    m_edges[idx].m_to = id_vert2;

    m_vertices[id_vert1].m_out.push_back(idx);
    m_vertices[id_vert2].m_in.push_back(idx);
}



void Graph::sauvegarder(std::string a)
{
    std::ofstream fichier(a, std::ios::out | std::ios::trunc);
    std::string picname;

    if(fichier)
    {
        fichier << Graph::ordre << std::endl;
        fichier << Graph::nbrEdge << std::endl;

        for (auto &elt : m_vertices)
        {
            fichier << elt.second.m_value << " ";
            fichier << elt.second.m_interface->m_top_box.get_frame_pos().x<<" ";
            fichier << elt.second.m_interface->m_top_box.get_frame_pos().y<<" ";
            picname=elt.second.m_interface->m_img.get_picname();
            picname.erase(picname.size()-4,4);
            fichier << picname + ".jpg" << std::endl;

        }

        for (auto &elt : m_edges)
        {
            fichier << elt.second.m_from<<" ";
            fichier << elt.second.m_to<<" ";
            fichier << elt.second.m_weight << std::endl;
        }
        fichier.close();
        //std::cout << "Sauvegarde faite.";
    }
}

void Graph::effacersommet(int id)
{
    m_supver.push_back(m_vertices[id]);
    for(auto &elmt: m_edges)
    {
        if(elmt.second.m_from==id || elmt.second.m_to==id)
        {
            m_supsom.push_back(m_edges[id]);
            effacerarete(elmt.first);
        }
    }

    Vertex &remed=m_vertices.at(id);







    /// Tester la coh�rence : nombre d'arc entrants et sortants des sommets 1 et 2





    /// test : on a bien des �l�ments interfac�s

    if (m_interface && remed.m_interface)

    {

        /// Ne pas oublier qu'on a fait �a � l'ajout de l'arc :

        /* EdgeInterface *ei = new EdgeInterface(m_vertices[id_vert1], m_vertices[id_vert2]); */

        /* m_interface->m_main_box.add_child(ei->m_top_edge);  */

        /* m_edges[idx] = Edge(weight, ei); */

        /// Le new EdgeInterface ne n�cessite pas de delete car on a un shared_ptr

        /// Le Edge ne n�cessite pas non plus de delete car on n'a pas fait de new (s�mantique par valeur)

        /// mais il faut bien enlever le conteneur d'interface m_top_edge de l'arc de la main_box du graphe

        m_interface->m_main_box.remove_child( remed.m_interface->m_top_box );

    }







    /// Le Edge ne n�cessite pas non plus de delete car on n'a pas fait de new (s�mantique par valeur)

    /// Il suffit donc de supprimer l'entr�e de la map pour supprimer � la fois l'Edge et le EdgeInterface

    /// mais malheureusement ceci n'enlevait pas automatiquement l'interface top_edge en tant que child de main_box !

    m_vertices.erase( id );
}

void Graph::effacerarete(int id)
{
    Edge &remed=m_edges.at(id);



    std::cout << "Removing edge " << id << " " << remed.m_from << "->" << remed.m_to << " " << remed.m_weight << std::endl;



    /// Tester la coh�rence : nombre d'arc entrants et sortants des sommets 1 et 2

    std::cout << m_vertices[remed.m_from].m_in.size() << " " << m_vertices[remed.m_from].m_out.size() << std::endl;

    std::cout << m_vertices[remed.m_to].m_in.size() << " " << m_vertices[remed.m_to].m_out.size() << std::endl;

    std::cout << m_edges.size() << std::endl;



    /// test : on a bien des �l�ments interfac�s

    if (m_interface && remed.m_interface)

    {

        /// Ne pas oublier qu'on a fait �a � l'ajout de l'arc :

        /* EdgeInterface *ei = new EdgeInterface(m_vertices[id_vert1], m_vertices[id_vert2]); */

        /* m_interface->m_main_box.add_child(ei->m_top_edge);  */

        /* m_edges[idx] = Edge(weight, ei); */

        /// Le new EdgeInterface ne n�cessite pas de delete car on a un shared_ptr

        /// Le Edge ne n�cessite pas non plus de delete car on n'a pas fait de new (s�mantique par valeur)

        /// mais il faut bien enlever le conteneur d'interface m_top_edge de l'arc de la main_box du graphe

        m_interface->m_main_box.remove_child( remed.m_interface->m_top_edge );

    }



    /// Il reste encore � virer l'arc supprim� de la liste des entrants et sortants des 2 sommets to et from !

    /// References sur les listes de edges des sommets from et to

    std::vector<int> &vefrom = m_vertices[remed.m_from].m_out;

    std::vector<int> &veto = m_vertices[remed.m_to].m_in;

    vefrom.erase( std::remove( vefrom.begin(), vefrom.end(), id ), vefrom.end() );

    veto.erase( std::remove( veto.begin(), veto.end(), id ), veto.end() );



    /// Le Edge ne n�cessite pas non plus de delete car on n'a pas fait de new (s�mantique par valeur)

    /// Il suffit donc de supprimer l'entr�e de la map pour supprimer � la fois l'Edge et le EdgeInterface

    /// mais malheureusement ceci n'enlevait pas automatiquement l'interface top_edge en tant que child de main_box !

    m_edges.erase( id );
}



void Graph::effacage()
{
        int clechoix;
        std::cout<<"Quel sommet voulez-vous effacer ?"<<std::endl;
        std::cin>>clechoix;
        effacersommet(clechoix);
}



void Graph::dynamique()
{
    for(auto &elmnt : m_vertices)
    {

        double co;
        for(int i=0; i<elmnt.second.m_in.size(); i++)
        {
            for(auto &elmnts : m_edges)
            {
                if(elmnts.second.m_from==elmnt.second.m_in[i] && elmnts.second.m_to==elmnt.first)
                {
                    co= co+elmnts.second.m_weight*(m_vertices[i].m_value/10);

                }
            }

            if(co==0)
            {
                co=1;
            }
            elmnt.second.m_value = elmnt.second.m_value - (0.0005*(elmnt.second.m_value*(1-(elmnt.second.m_value/co))));
        }
    }
}
