#include "grman/grman.h"
#include <iostream>

#include "graph.h"

int main()
{
    /// A appeler en 1er avant d'instancier des objets graphiques etc...
    grman::init();

    /// Le nom du r�pertoire o� se trouvent les images � charger
    grman::set_pictures_path("pics");

    /// Un exemple de graphe
    Graph g;

    int choix1,choix2,b;
    int z=0;
    int x=0;
    std::string a;

    while(!key[KEY_ESC])
    {
        if(z!=0)
        {
            g.clearMap();
            z=1;
        }

        while(!key[KEY_D])
        {
            a=g.menu1(a);
            grman::mettre_a_jour();
        }

        g.make_example(a);
        z=1;

    /// Vous gardez la main sur la "boucle de jeu"
    /// ( contrairement � des frameworks plus avanc�s )
    while ( !key[KEY_G] )
    {
        /// Il faut appeler les m�thodes d'update des objets qui comportent des widgets
        if(key[KEY_SPACE])
        {
            g.dynamique();
        }

        g.update();

        /// Mise � jour g�n�rale (clavier/souris/buffer etc...)
        grman::mettre_a_jour();
        g.sauvegarder(a);
    }
  }
    grman::fermer_allegro();

    return 0;
}
END_OF_MAIN();


